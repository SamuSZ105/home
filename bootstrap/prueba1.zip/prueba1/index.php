<!DOCTYPE html>
<?php
include_once 'conn.php';
session_start();


$testred=$_SERVER['REQUEST_URI'];
if ($testred != "/prueba1/index.php") {
header("Location: ../index.php ");
}
else {

}

if(!isset($_SESSION['user_session']))
{
  //echo $_SESSION['user_session']."jajaja";
}
else{
  $stmt = $db_con->prepare("SELECT * FROM tbl_users WHERE user_id=:uid");
  $stmt->execute(array(":uid"=>$_SESSION['user_session']));
  $row=$stmt->fetch(PDO::FETCH_ASSOC);

   if ($row['user_name']!="") {
     header("Location: welcome.php");
   }

}
?>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <!-- bootstrap 5 css -->
    <!--   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha2/css/bootstrap.min.css" integrity="sha384-DhY6onE6f3zzKbjUPRc2hOzGAdEf4/Dz+WJwBvEYL/lkkIsI3ihufq9hk9K4lVoK" crossorigin="anonymous">-->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <!-- custom css -->
    <link rel="stylesheet" href="style/style.css">
    <link rel="stylesheet" type="text/css" href="lib/sweetalerts2/dark.css">
</head>

<body>


  <div id="wrapper">
   <div class="overlay"></div>

        <!-- Sidebar -->
    <nav class="fixed-top align-top" id="sidebar-wrapper" role="navigation">
       <div class="simplebar-content" style="padding: 0px;">
				<a class="sidebar-brand" href="index.php">
          <span class="align-middle">Page</span>
        </a>

				 <ul class="navbar-nav align-self-stretch">

<li class="sidebar-header">
						Páginas
					</li>



       <li class="lihover">
		  <a href="#" class="nav-link collapsed text-left active"  role="button">
           Login
         </a>

		  </li>
      <li class="lihover">
          <a class="nav-link text-left"  role="button"
          aria-haspopup="true" aria-expanded="false" href="registrarse.php">
          Registrarse
             </a>
          </li>

          <!--
           <li class="lihover">
          <a class="nav-link text-left"  role="button"
          aria-haspopup="true" aria-expanded="false" href="login.php">
          Welcome
             </a>
          </li>-->

		  </ul>


			</div>


    </nav>
        <!-- /#sidebar-wrapper -->










        <!-- Page Content -->
        <div id="page-content-wrapper">


			<div id="content">

       <div class="container-fluid p-0 px-lg-0 px-md-0">
        <!-- Topbar -->
        <nav class="navbar navbar-expand navbar-light my-navbar">

          <!-- Sidebar Toggle (Topbar) -->
            <div type="button"  id="bar" class="nav-icon1 hamburger animated fadeInLeft is-closed" data-toggle="offcanvas">
               <span></span>
			    <span></span>
				 <span></span>
            </div>


          <!-- Topbar  -->
          <ul class="navbar-nav mr-auto">
            <li>
            </li>
          </ul>


          <!-- Topbar Navbar -->
          <ul class="navbar-nav ml-auto">



              <!-- Nav Item - Alerts -->

              <!-- Nav Item - Messages -->


              <!-- Nav Item - User Information -->
              <li class="nav-item dropdown">
                <a class="nav-link " href="#" id="userDropdown" role="button" data-toggle="dropdown">
                  <span class="mr-2 d-none d-lg-inline text-gray-600 small"></span>
                  <img class="img-profile" src="img/innologo2.png">
                </a>
              </li>

            </ul>

        </nav>
        <!-- End of Topbar -->

        <!-- Begin Page Content -->
        <div class="container-fluid px-lg-4">
          <div class="row">
          <div class="col-md-12 mt-lg-4 mt-4" style="padding-top: 20px;
    background: darkcyan;margin: 0px!important;">
                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                      <h1 class="h3 mb-0 text-gray-800" style="margin:auto; color:white!important;">Login</h1>
                    </div>
          		  </div>
          <div class="col-md-12">
            <div id="contentt" style=" min-height: 400px; width: 95%; margin: auto;">


                  <div class="top-img"></div>
                  <form class="col-lg-5 col-md-7 col-sm-8 col-10 shadow bg-black p-5 text-center needs-validation" novalidate style="margin:auto; padding: 1rem!important;"   id="myform">
                    <div class="row">
             <div class="col">
               <a href="#" class="btn text-white text-uppercase rounded-0 mt-5 mb-4 btn-block hoverr">Iniciar sesión</a>
             </div>
             <div class="col">
              <a href="registrarse.php" class="btn text-white text-uppercase rounded-0 mt-5 mb-4 btn-block hoverr">Registrarse</a>
             </div>
             </div>
                        <hr>

                      <div class="form-row">
                        <div class="col">
                        <input type="text" class="form-control my-4 rounded-0 p-0" id="username" placeholder="Usuario *" name="username" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Usuario *'" required />
                        <div class="invalid-feedback">
                        Ingrese un usuario
                       </div>
                         </div>
          </div>
          <div class="form-row">
            <div class="col">
            <input type="password" class="form-control my-4 rounded-0 p-0 " id="pass" placeholder="Contraseña *" name="pass" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Contraseña *'" minlength="5" required />
            <div class="invalid-feedback">
            Ingrese la contraseña
           </div>
             </div>
  </div>
                      <button type="submit" class="btn text-white text-uppercase rounded-0 mt-5 mb-4 btn-block hoverr">Login</button>
                      <a href="#" class="f-pass">Forgot Password?</a>
                  </form>



          </div>



                              <!-- column -->



                  </div>

        </div>
        <!-- /.container-fluid -->

      </div>








      <footer style="height:auto;">
        <p style="text-align:center; color:white!important;">Copyright © 2021 - All rights reserved.</p>
      </footer>

        </div>
		</div>
        <!-- /#page-content-wrapper -->

    </div>







    <!-- bootstrap 5 js -->
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
  <!--  <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha2/js/bootstrap.min.js" integrity="sha384-5h4UG+6GOuV9qXh6HqOLwZMY4mnLPraeTrjT5v07o347pj6IkfuoASuGBhfDsp3d" crossorigin="anonymous"></script> -->
  <script src="js/jquery351.slim.min.js"></script>
  <script src="js/popper.js"></script>

  <script src="login.js"></script>
  <script src="js/bootstrap.min.js"></script>
    <script src="lib/sweetalerts2/sweetalert2.min.js"></script>
    <script>
    // Example starter JavaScript for disabling form submissions if there are invalid fields
(function () {
  'use strict'

  // Fetch all the forms we want to apply custom Bootstrap validation styles to
  var forms = document.querySelectorAll('.needs-validation')

  // Loop over them and prevent submission
  Array.prototype.slice.call(forms)
    .forEach(function (form) {
      form.addEventListener('submit', function (event) {
        if (!form.checkValidity()) {
          event.preventDefault()
          event.stopPropagation()
        }

        form.classList.add('was-validated')
      }, false)
    })
})()



$('#bar').click(function(){
 $(this).toggleClass('open');
 $('#page-content-wrapper ,#sidebar-wrapper').toggleClass('toggled' );



});





     </script>
</body>

</html>
