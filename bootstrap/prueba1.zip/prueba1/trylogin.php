<?php
 session_start();
 require_once 'conn.php';
 //fname=Jonathan&lname=Cortez&username=SamuSZ&email=jonathan_cortez_fdz%40hotmail.com&pass1=samus666&pass2=samus666
 if($_POST)
 {
  $user_name = trim($_POST['username']);
  $user_password = trim($_POST['pass']);

  $password = md5($user_password);

  try
  {

   $stmt = $db_con->prepare("SELECT * FROM tbl_users WHERE user_name=:username");
   $stmt->execute(array(":username"=>$user_name));
   $row = $stmt->fetch(PDO::FETCH_ASSOC);
   //$count = $stmt->rowCount();

   if($row['user_password']==$password){

    echo "1"; // log in
    $_SESSION['user_session'] = $row['user_id'];

   }
   else{

  echo "0";// wrong details
   }

  }
  catch(PDOException $e){
   echo $e->getMessage();
  }
 }

?>
