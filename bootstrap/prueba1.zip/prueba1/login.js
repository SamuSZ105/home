$("#myform").submit(function(){
if ($("#myform")[0].checkValidity()){
  var formData = new FormData($(this)[0]);
  $.ajax({
      url: 'trylogin.php',
      type: 'POST',
      data: formData,
      async: false,
      success: function (data) {
        if (data>0) {


        Swal.fire(
'Exito!',
'Iniciando Sesión!',
'success'
);
setTimeout(function () {
 window.location.href = "index.php"; //will redirect to your blog page (an ex: blog.html)
}, 2000); //will call the function after 2 secs.
      }
      else {
        Swal.fire({
  type: 'error',
  title: 'Oops...',
  text: 'Usuario y/o Contraseña incorrecots'

})

      }


    },
      cache: false,
      contentType: false,
      processData: false
  });

  return false;

}

   else
       //Validate Form
       $("#myform")[0].reportValidity()
});
