$("#myform").submit(function(){
if ($("#myform")[0].checkValidity()){
  var formData = new FormData($(this)[0]);

  $.ajax({
      url: 'reg.php',
      type: 'POST',
      data: formData,
      async: false,
      success: function (data) {
        if (data==1) {
          Swal.fire(
'Listo!',
'Registro Completado!',
'success'
);
setTimeout(function () {
   window.location.href = "welcome.php"; //will redirect to a page
}, 2000); //will call the function after 2 secs.

        }
        if (data==0) {
          Swal.fire({
    type: 'error',
    title: 'Oops...',
    text: 'Algo salio mal'

  })
        }
        if (data==2) {
          Swal.fire({
    type: 'error',
    title: 'Oops...',
    text: 'Usuario y/o email ya registrado'

  })
        }

      },
      cache: false,
      contentType: false,
      processData: false
  });

  return false;
}

   else
       //Validate Form
       $("#myform")[0].reportValidity()
});
