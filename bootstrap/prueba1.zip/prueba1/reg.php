<?php
require_once 'conn.php';


if($_POST){

   //fname=Jonathan&lname=Cortez&username=SamuSZ&email=jonathan_cortez_fdz%40hotmail.com&pass1=samus666&pass2=samus666
  $fname = $_POST['fname'];
  $lname = $_POST['lname'];
  $username = $_POST['username'];
  $email = $_POST['email'];
  $pass = $_POST['pass1'];
  $pass = md5($pass);
  //$date = DateTime::createFromFormat('m-d-Y',date("m-d-Y"));
  //$forSQL = $date->format('Y-m-d');
  $checkEmailQuery = $conn->prepare("SELECT * FROM tbl_users WHERE user_email = ?");
  $checkEmailQuery->bind_param("s", $email);
  $checkEmailQuery->execute();
  $result = $checkEmailQuery->get_result();
  if ($result->num_rows > 0) {
          echo 2;
          return 0;
  }

  $checkUserQuery = $conn->prepare("SELECT * FROM tbl_users WHERE user_name = ?");
  $checkUserQuery->bind_param("s", $username);
  $checkUserQuery->execute();

  $result2 = $checkUserQuery->get_result();
  if ($result2->num_rows > 0) {
          echo 2;
          return 0;
  }




    // cover_image is empty (and not an error)
    $stringquery = "INSERT INTO tbl_users(user_fname,user_lname,user_name,user_email,user_password) VALUES(?,?,?,?,?)";
    $insertQuery = $conn->prepare($stringquery);
    $insertQuery->bind_param("sssss",$fname,$lname,$username,$email,$pass);

    if ($insertQuery->execute()) {

      echo 1;




  }else {
    echo 0;
  }

}

?>
