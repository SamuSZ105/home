
/*   Seleccion*/
var marca = document.querySelector('#marca');
var modelo = document.querySelector('#modelo');
var anio = document.querySelector('#anio');

var options2 = modelo.querySelectorAll('option');
var options3 = anio.querySelectorAll('option');

function giveSelection(selValue) {
  modelo.innerHTML = '';
  for(var i = 0; i < options2.length; i++) {
    if(options2[i].dataset.option === selValue) {
      modelo.appendChild(options2[i]);
    }
  }
}

giveSelection(marca.value);
/*
function giveSelection2(selValue) {
anio.innerHTML = '';
for(var i = 0; i < options3.length; i++) {
if(options3[i].dataset.option === selValue) {
anio.appendChild(options3[i]);
}
}
}

giveSelection2(modelo.value);
*/


function datosduros(){

  var $marca =document.getElementById("marca").value;
  var $modelo =document.getElementById("modelo").value;
  var $anio =document.getElementById("anio").value;
  var $serie =document.getElementById("serie").value;
  var $email =document.getElementById("user_email").value;
  var $cilindros =document.getElementById("cilindros").value;
  var $lujo= "";
  var $ecologico= "";
  var $checkBox = document.getElementById("myCheck");
  var $checkBox2 = document.getElementById("myCheck2");

  if ($checkBox.checked == true){
    $ecologico = "Si";
  } else {
    $ecologico = "No";
  }
  if ($checkBox2.checked == true){
    $lujo = "Si";
  } else {
    $lujo = "No";
  }

//alert($marca + ", " + $modelo + ", " + $anio + ", " + $serie + ", " + $cilindros + ", " + $lujo + ", " + $email + ", " + $ecologico);
$("#modall").modal();

myData = {marca:$marca,modelo:$modelo,anio:$anio,serie:$serie,email:$email};
//myData2 = [$marca,$modelo,$anio,$serie,$cilindros,$lujo,$email,$ecologico];
//alert(myData2);

//$.ajax({
//  async: true,
//  url: 'test.php',
//  type:"get",
//  data:myData,
//  success: function(){

//}

//});
llenado();
};




function precioautonolujo(anio){
  var i;
  var valorporanio=1500;
  for(i=1995;i<2025;i++){
  if(anio==i){
    return valorporanio;
  }
  valorporanio+=100;
}
  return 1;
}

function precioautolujo(anio){
  var i;
  var valorporanio=2000;
  for(i=1995;i<2025;i++){
  if(anio==i){
    return valorporanio;
  }
  valorporanio+=100;
}
return 1;
}
